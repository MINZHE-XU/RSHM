let nextTodoId = 0
export const ADD_SPOT='ADD_SPOT'
export const CENTER_SPOT='CENTER_SPOT'

export function addSpot(text) {
  return { type:ADD_SPOT , id: nextTodoId++, text }
}

export function clickListSpot(text) {
  console.log('clicked',text)
  return { type:CENTER_SPOT , text }
}
