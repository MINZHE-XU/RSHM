import React, { Component } from 'react';
import AddSpot from '../containers/AddSpot'
import ShowSpot from '../containers/ShowSpot'
import MapWithControlledZoom from '../containers/MapNew0'

class App extends Component {
  render() {
    return (
      <div>
        <AddSpot />
        <ShowSpot />
        <MapWithControlledZoom />
      </div>
    );
  }
}

export default App;
