import { combineReducers } from 'redux'
import spots from './spots'

const todoApp = combineReducers({
  spots
})

export default todoApp
