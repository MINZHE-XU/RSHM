const spots = (state = [], action) => {
  switch (action.type) {
    case 'ADD_SPOT':
      return [
        ...state,
        {
          id: action.id,
          text: action.text,
          completed: false
        }
      ]
    default:
      return state
  }
}

export default spots
