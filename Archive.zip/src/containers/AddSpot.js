import React from 'react'
import  Component from 'react'
import {bindActionCreators} from 'redux';
import { connect } from 'react-redux'
import { addSpot } from '../actions'

class AddSpot extends React.Component {
  constructor() {
    super();
  }
  render() {
    return (
      <div>
        <input type='text' ref='input' />
        <button onClick={(e) => this.handleClick(e)}>
          Add
        </button>
      </div>
    )
  }

  handleClick(e) {
    const node = this.refs.input;
    const text = node.value.trim();
    this.props.addSpot(text);
    node.value = '';
  }
}

function mapDispatchToProps(dispatch){
  return bindActionCreators({ addSpot }, dispatch)
}
export default connect( null,mapDispatchToProps)(AddSpot);
